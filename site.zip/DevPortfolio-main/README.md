# Tamoghna Kommaraju's Portfolio Website
The official Developer Portfolio Website for Tamoghna Kommaraju. To view the published site, go to [**www.tamoghnak.tk**](https://www.tamoghnak.tk/).

<p>Like this? Then don't forget to support me by starring this repository!</p>

Credits:
<p><sup>Domain Hosting from Freenom.com</sup></p>
<p><sup>SSL Certificate from Cloudflare</sup></p>
<p><sup>Music from Bensound.com</sup></p>
<p><sup>Created with GitHub and Replit</sup></p>
<p><sup>Tested locally with Web Server for Chrome</sup></p>
<p><sup>Made on a Chromebook</sup></p>


